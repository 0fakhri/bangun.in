<?php $__env->startSection('content'); ?>
<?php if(session('error')): ?>
<!-- Modal -->
    <div class="alert alert-danger" role="alert">
      <?php echo e(session('error')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    </div>
  <?php endif; ?>
    <main class="login-bg">
        <!-- Register Area Start -->
        <div class="register-form-area">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="register-form text-center">
                            <!-- Login Heading -->
                            <div class="register-heading">
                                <span>Sign Up</span>
                                <p>Create your account to get full access</p>
                            </div>
                            <div class="container row justify-content-center">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                      <a class="nav-link" id="home-tab" data-toggle="tab" href="#Customer" role="tab" aria-controls="home"
                                      aria-selected="true" style="color: rgb(92, 92, 92);">Customer</a>
                                    </li>
                                    <li class="nav-item">
                                      <a class="nav-link" id="CV-tab" data-toggle="tab" href="#CV" role="tab" aria-controls="profile"
                                      aria-selected="false" style="color: rgb(92, 92, 92);">CV Perencana</a>
                                    </li>
                                </ul>
                            </div>
                            <!-- Single Input Fields -->
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade" id="Customer" role="tabpanel" aria-labelledby="home-tab">
                                    <form class="input-box" method="POST" action="/regCu">
                                        <?php echo csrf_field(); ?>
                                        <!-- <div class="input-box"> -->
                                        <div class="single-input-fields">
                                            <label>Full name</label>
                                            <input name="nama" type="text" placeholder="Masukkan full name" class="<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <div class="single-input-fields">
                                            <label>Email Address</label>
                                            <input name="email" type="email" placeholder="Masukkan email address" class="<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e(session('error')); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                        <input type="hidden" name="role" value="customer">
                                        <div class="single-input-fields">
                                            <label>Password</label>
                                            <input name="password" type="password" placeholder="Masukkan Password" class="<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        </div>
                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        <!-- <div class="single-input-fields">
                                            <label>Confirm Password</label>
                                            <input name="password_confirmation" type="password" placeholder="Confirm Password" >
                                        </div> -->
                                        <!-- form Footer -->
                                        <div class="register-footer">
                                            <p> Already have an account? <a href="<?php echo e(route('login')); ?>"> Login</a> here</p>
                                            <button type="submit" class="submit-btn3">Sign Up</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="CV" role="tabpanel" aria-labelledby="CV-tab">
                                    <form class="input-box" method="POST" action="/regCu" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                    <!-- <div class="input-box"> -->
                                        <div class="single-input-fields">
                                            <label>Nama CV</label>
                                            <input name="nama_cv" type="text" placeholder="Masukkan nama CV">
                                        </div>
                                        <div class="single-input-fields">
                                            <label>Email Address</label>
                                            <input name="email" type="email" placeholder="Masukkan email address">
                                        </div>
                                        <div class="single-input-fields">
                                            <label>Password</label>
                                            <input name="password" type="password" placeholder="Masukkan Password">
                                        </div>
                                        <input type="hidden" name="role" value="cv">
                                        <!-- <div class="single-input-fields">
                                            <label>Confirm Password</label>
                                            <input type="password" placeholder="Confirm Password">
                                        </div> -->
                                        <div class="single-input-fields">
                                            <label>Alamat</label>
                                            <input name="alamat" type="text" placeholder="Alamat">
                                        </div>
                                        
                                        <div class="single-input-fields">
                                            <label>Upload Bukti</label>
                                            <input type="file" name="img" placeholder="Bukti">
                                        </div>
                                        <!-- form Footer -->
                                        <div class="register-footer">
                                            <p> Already have an account? <a href="<?php echo e(route('login')); ?>"> Login</a> here</p>
                                            <button type="submit" class="submit-btn3">Sign Up</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Register Area End -->
    </main>

<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Register')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Project\bangunin\resources\views/auth/register.blade.php ENDPATH**/ ?>