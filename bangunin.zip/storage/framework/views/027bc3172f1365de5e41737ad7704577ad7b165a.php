<?php $__env->startSection('content'); ?>
<?php if(session('sukses')): ?>
    <div class="alert alert-success" role="alert">
      <?php echo e(session('sukses')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    </div>
  <?php endif; ?>
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <div class="col-sm-12 col-md-6">
    <h6 class="m-0 font-weight-bold text-primary">EDIT Data ADMIN</h6>
    </div>
  </div>
  <div class="card-body" style="font-size: 15px;">
      <div class="table-responsive">
<form action="/admin/<?php echo e($users->id); ?>/update" method="POST" >
        	<?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label >Nama</label>
        <input name="name" type="text" class="form-control" id="name" value="<?php echo e($users->name); ?>">
      </div>
     <div class="form-group">
          <label >Email</label>
          <input name="email" type="email" class="form-control" id="email" value="<?php echo e($users->email); ?>">
        </div>
        <div class="form-group">
          <label >username</label>
          <input type="text" class="form-control" id="username" name="username" value="<?php echo e($users->username); ?>">
        </div>
        <div class="form-group">
          <label >password</label>
          <input type="password" class="form-control" id="password" name="password" value="<?php echo e($users->password); ?>" readonly></div>
     <button type="submit" class="btn btn-primary">update</button>
     </div>
      </form>
      </div>
      </div>
      
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Project\bangunin\resources\views/admin/editadmin.blade.php ENDPATH**/ ?>