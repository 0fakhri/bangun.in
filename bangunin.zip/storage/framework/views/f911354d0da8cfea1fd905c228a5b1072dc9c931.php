<?php $__env->startSection('content'); ?>

<?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
    <script>
    swal({
        title: "Data harap diisi",
        
        icon: "warning",
        button: "Ok",
    });
    </script>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
<?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?>
    <script>
    swal({
        title: "Data harap diisi",
        
        icon: "warning",
        button: "Ok",
    });
    </script>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
<?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?>
    <script>
    swal({
        title: "Data harap diisi",
        
        icon: "warning",
        button: "Ok",
    });
    </script>
<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>




<main class="login-bg">
    <!-- login Area Start -->
    <div class="login-form-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 col-lg-8">
                    <div class="login-form">
                        <!-- Login Heading -->
                    <?php if(empty($produk)): ?>
                        <div class="login-heading">
                            <span>Tambah produk</span>
                            <p></p>
                        </div>
                        <form method="POST" action="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        <!-- Single Input Fields -->
                            <div class="input-box">
                                <div class="single-input-fields">
                                    <label>Nama Produk</label>
                                    <input name="nama" class="<?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" >
                                </div>
                                <div class="single-input-fields">
                                    <label>Harga Produk</label>
                                
                                    <input name="harga" class="<?php if ($errors->has('harga')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('harga'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="number" placeholder="">
                                </div>
                                <div class="single-input-fields">
                                    <label>Foto produk</label>
                                    <input type="file" name="img" placeholder="foto" class="<?php if ($errors->has('img')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('img'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" >
                                </div>
                                
                            </div>
                            <!-- form Footer -->
                            <div class="login-footer">
                                <button type="submit" class="submit-btn3">Simpan</button>
                                <a href="./" class="btn btn-secondary">Batal</a>
                            </div>
                            
                        </form>
                        
                    <?php elseif(!empty($produk)): ?>
                        <!-- Login Heading -->
                        <div class="login-heading">
                            <span>Update produk</span>
                            <p></p>
                        </div>
                        <form method="POST" action="../postEdit" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                        <!-- Single Input Fields -->
                            <div class="input-box">
                                <div class="single-input-fields">
                                    <label>Nama Produk</label>
                                    <input name="nama" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="text" value=" <?php echo e($produk->nama_produk); ?> ">
                                    
                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <input type="hidden" name="id" value=" <?php echo e($produk->id); ?> ">
                                <div class="single-input-fields">
                                    <label>Harga Produk</label>
                                
                                    <input name="harga" class="<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" type="number" placeholder="" value="<?php echo e($produk->harga); ?>">
                                </div>
                                <div class="single-input-fields">
                                    <label> produk</label>
                                    <input type="file" name="img" placeholder="foto">
                                </div>
                            </div>
                            <!-- form Footer -->
                            <div class="login-footer">
                                <button type="submit" class="submit-btn3">Simpan</button>
                                <a href="../" class="btn btn-secondary">Batal</a>
                            </div>
                        </form>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cv.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\Project\bangunin\resources\views/cv/inputProduk.blade.php ENDPATH**/ ?>